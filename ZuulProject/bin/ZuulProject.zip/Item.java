
public class Item {
	
	String description;
	
	//constructor
	public Item(String newDescription) {
		description = newDescription;
	}
	
	public String getDescription() {
		return description;
	}
}
